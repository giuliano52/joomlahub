DROP TABLE IF EXISTS `#__pqz_lnk_quiz_category`;

DROP TABLE IF EXISTS `#__pqz_lnk_quiz_question` ;

DROP TABLE IF EXISTS `#__pqz_question` ;

DROP TABLE IF EXISTS `#__pqz_quiz_categories` ;

DROP TABLE IF EXISTS `#__pqz_quiz_name` ;

