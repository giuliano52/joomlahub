<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
View di defalt se non viene indicata una view
per ora lasciata vuota per scopi futuri. 

