PQZ
===
Il path dei file contenuti nella campo della tabella #__pqz_quiz_name.question_filename si riferiscono al path di joomla (JPATH_ROOT)
