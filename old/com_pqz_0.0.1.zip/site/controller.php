<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controller library
jimport('joomla.application.component.controller');

class PqzController extends JControllerLegacy {

    public function display($cachable = false, $urlparams = false) {
        return parent::display($cachable, $urlparams);
    }

    public function quiz_start($cachable = false, $urlparams = false) {
        //inizialize the quiz 
        unset($_SESSION['pqz_quiz_conf']);
        unset($_SESSION['pqz_quiz_question']);


        $jinput = JFactory::getApplication()->input;
        $id_quiz = $jinput->get('id_quiz', '0', 'integer');

        // set the view quiz_start
        $jinput->set('view', 'quiz_start');

        $model = $this->getModel();
        $model->QuizInitialize($id_quiz);
        return parent::display($cachable, $urlparams);
    }

    public function ask_question($cachable = false, $urlparams = false) {
        // show a question
        $jinput = JFactory::getApplication()->input;
        $id_question = $jinput->get('id_question', '0', 'integer');
        $answer = $jinput->get('q_0', '', 'string');

        $model = $this->getModel();

        if ($answer != '') {
            $model->storeAnswer($id_question, $answer);
            $id_question ++;
        }

        $id_question = min(max($id_question, 0), $_SESSION['pqz_quiz_conf']['num_question'] - 1);

        $model->getQuestion($id_question);

        // set the view
        $jinput->set('view', 'ask_question');

        // $view = $this->getView();
        $view = $this->getView('ask_question', 'html');
        $view->setModel($model, true);

        return parent::display($cachable, $urlparams);
    }

    public function see_results($cachable = false, $urlparams = false) {
        $jinput = JFactory::getApplication()->input;

        $model = $this->getModel();
        $model->final_verify_correct_answer();
        // set the view
        $jinput->set('view', 'see_results');

        $view = $this->getView('see_results', 'html');
        $view->setModel($model, true);
        return parent::display($cachable, $urlparams);
    }

    public function edit_single_csv($cachable = false, $urlparams = false) {
        $jinput = JFactory::getApplication()->input;
        $id_quiz = $jinput->get('id_quiz', '0', 'integer');
        $model = $this->getModel();
        $model->QuizInitialize($id_quiz);
        $jinput->set('view', 'edit_single_csv');
        return parent::display($cachable, $urlparams);
    }

    public function modify_question($cachable = false, $urlparams = false) {


        $jinput = JFactory::getApplication()->input;

        $id_quiz = $jinput->get('id_quiz', '0', 'integer');
        $id_question = $jinput->get('id_question', '0', 'integer');
        $model = $this->getModel();
        $data_list = $model->getData($id_quiz, $id_question);

        $jinput->set('view', 'modify_question');


        //      $this->items = $data_list;

        return parent::display($cachable, $urlparams);
    }

}
