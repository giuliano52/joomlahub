<?php

/*
 * Copyright (C) 2014 test01
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Description of pqz
 *
 * @author test01
 */
class pqz {

    public $configuration = array(
        'title' => array(
            'value' => "Rispondi alle domande",
            'description' => 'title of the quiz',
            'changable' => false
        ),
        'num_options' => array(
            'value' => 4,
            'description' => 'Number of options for each question (valid in only multiple choice question)',
            'changable' => true
        ),
        'num_question_per_page' => array(
            'value' => 1,
            'description' => 'Number of question for each page (0 means all question in a single page)',
            'changable' => true),
        'max_question_total' => array(
            'value' => 6,
            'description' => 'Total Number of the questions (0 means all available)',
            'changable' => true
        ),
        'min_diffucult_level' => array(
            'value' => 0,
            'description' => 'Minimun difficult of the question (0-100) use the following range : 10 very easy, 20 easy, 30 medium, 40 hard, 50 very-hard, &gt;50 impossible',
            'changable' => true
        ),
        'max_diffucult_level' => array(
            'value' => 100,
            'description' => 'Maximum difficult of the question (0-100) use the following range : 10 very easy, 20 easy, 30 medium, 40 hard, 50 very-hard, &gt;50 impossible',
            'changable' => true
        ),
        'default_response_type' => array(
            'value' => "options",
            'description' => 'Default response type use: (options = multiple choice, text = free answer) ',
            'changable' => true
        ),
        'randomize_question' => array(
            'value' => "true",
            'description' => 'Randomize questions',
            'changable' => true
        ),
        'reverse_question' => array(
            'value' => "false",
            'description' => 'Reverse question with answer',
            'changable' => true
        ),
        'tags' => array(
            'value' => "",
            'description' => 'Filter the quiz with tags (leave empty if you dont want to filter it)',
            'changable' => true
        ),
        'congratulation_file' => array(
            'value' => 'data/conf/congratulation-girl6.csv',
            'description' => 'source data for the image shown if you win the quiz',
            'changable' => false
        ),
        'question_filename' => array(
            'value' => '',
            'description' => 'quiz name that contain the questions (in case of ods file you can select a sheet: quiz_prova.ods#Sheet2)',
            'changable' => false
        ),
    );
    public $quiz_questions = array();
    public $question_fields = array(
        'id' => array(
            'description' => 'An id of the question',
            'required' => false,
            'filter' => FILTER_SANITIZE_ENCODED,
        ),
        'question' => array(
            'description' => 'Question',
            'required' => true,
            'filter' => FILTER_SANITIZE_ENCODED,
        ),
        'correct_answer' => array(
            'description' => 'Correct Answer',
            'required' => true,
            'filter' => FILTER_SANITIZE_ENCODED,
        ),
        'wrong_answer' => array(
            'description' => 'Possible wrong answer (separated by |)',
            'required' => false,
            'filter' => FILTER_SANITIZE_ENCODED,
        ),
        'difficult_level' => array(
            'description' => 'difficult of the question (0-100) use the following range : 10 very easy, 20 easy, 30 medium, 40 hard, 50 very-hard, &gt;50 impossible',
            'required' => false,
            'filter' => FILTER_VALIDATE_INT,
            'options' => array('min_range' => 1, 'max_range' => 100)
        ),
        'response_type' => array(
            'description' => 'response type use: (options = multiple choice, text = free answer)',
            'required' => false,
            'filter' => FILTER_SANITIZE_ENCODED,
        ),
        'tags' => array(
            'description' => 'Possible tags of the question, used for sub-categories (separated by |)',
            'required' => false,
            'filter' => FILTER_SANITIZE_ENCODED,
        ),
    );

    public function read_quiz_conf($xml_fullfilename) {

// read xml from file and overrite default _session values

        if (!file_exists($xml_fullfilename)) {
            $current_dir = getcwd();
            die("File xml -$xml_fullfilename- not found <br> Current dir = $current_dir");
        }
        $xml = simplexml_load_file($xml_fullfilename);
        foreach ($xml->children() as $child) {
            if (isset($this->configuration[$child->getName()]['value'])) {
                $this->configuration[$child->getName()]['value'] = (string) $child;
            }
        }
    }

    public function generate_question() {
        /* generate the array $quiz_questions with all the question 
         * TODO : use data from database
         */

        $data_quiz_src_orig = $this->load_from_source($this->configuration['question_filename']['value']);



        // filter unwanted question (tags, diff level, void )
        $data_quiz_src_filtered = $this->quiz_filter($data_quiz_src_orig, $this->configuration['tags']['value'], $this->configuration['min_diffucult_level']['value'], $this->configuration['max_diffucult_level']['value']);

      
        // reverse question with_answer
        if ($this->configuration['reverse_question']['value'] == TRUE) {
            $data_quiz_src_filtered = $this->quiz_switch_question_with_answer($data_quiz_src_filtered);
        }


        // generate question and answer
        $data_quiz_src = $this->quiz_generate($data_quiz_src_filtered);


        // randomize quiz 
        if ($this->configuration['randomize_question']['value'] == TRUE) {
            shuffle($data_quiz_src);
        }


        // restrict the maxium number of question
        if ($this->configuration['max_question_total']['value'] > 0) {
            $this->configuration['max_question_total']['value'] = min(count($data_quiz_src), $this->configuration['max_question_total']['value']);
        } else {
            $this->configuration['max_question_total']['value'] = count($data_quiz_src);
        }
        $this->quiz_questions = array_slice($data_quiz_src, 0, $this->configuration['max_question_total']['value']);



        // return $this->quiz_questions;
    }

    private function load_from_source($quiz_name) {
//load data from a source file

        $file_data = explode("#", $quiz_name);
        $quiz_filename = $file_data[0];

        if (!file_exists($quiz_filename)) {
            die("Source file -$quiz_filename- not found");
        }

        $ext = pathinfo($quiz_filename, PATHINFO_EXTENSION);
        if (strtoupper($ext) == "CSV") {
// is a 
            $data_quiz_src = $this->csv_to_array($quiz_filename);
        } elseif (strtoupper($ext) == "ODS") {
            $quiz_sheet = isset($file_data[1]) ? $file_data[1] : "";
            $data_quiz_src = $this->ods_to_array($quiz_filename, $quiz_sheet);
        } elseif (strtoupper($ext) == "SQLITE") {
            $quiz_name = isset($file_data[1]) ? $file_data[1] : "";
            $data_quiz_src = $this->sqlite_to_array($quiz_filename, $quiz_name);
        } else {
            die("$quiz_name: Unkown format");
        }

        return $data_quiz_src;
    }

    private function ods_to_array($filename, $sheet_name = 0) {
// extract values from an ods file to an array
// using SpreadsheetReader.php
        $out = array();


        $Spreadsheet = new SpreadsheetReader($filename);
        $Sheets = $Spreadsheet->Sheets();

        $sheet_index = array_search($sheet_name, $Sheets);

        $Spreadsheet->ChangeSheet($sheet_index);
        foreach ($Spreadsheet as $Row) {
            $out[] = $Row;
        }


        return $this->associate_first_row($out);
    }

    private function csv_to_array($filename = '', $delimiter = ';') {
// convert a csv file to an array

        if (!file_exists($filename) || !is_readable($filename))
            return FALSE;

        $header = NULL;
        $data = array();
        if (($handle = fopen($filename, 'r')) !== FALSE) {
            while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE) {
                if (empty($row))
                    continue;
                if (!$header)
                    $header = $row;
                else
                    $data[] = array_combine($header, $row);
            }
            fclose($handle);
        }
        return $data;
    }

    private function sqlite_to_array($db_filename, $quizname = "", $quiz_tags = "") {
        /* import a table into an array */
        $question_fields = $this->question_fields;

        $quizname = filter_var($quizname, FILTER_SANITIZE_STRING);
        $out = array();
        $i = 0;
        $db = new SQLite3($db_filename);

        $query = 'SELECT ' . implode(',', array_keys($question_fields)) . ' FROM quiz WHERE quiz_name LIKE "%' . $quizname . '%"';
        $result = $db->query($query) or die("query: $query failed");
        while ($res = $result->fetchArray()) {
            foreach ($question_fields as $field => $filter_type) {
                $out[$i][$field] = $res[$field];
            }
            $i++;
        }
        return $out;
    }

    private function associate_first_row($array_in) {
//	return an array with the keys taken from the first row
        $out = array();
        $ident = array_shift($array_in);
        foreach ($array_in as $key_r => $row) {
            foreach ($row as $key_c => $cell) {
                $out[$key_r][$ident[$key_c]] = $cell;
            }
        }
        return $out;
    }

    private function quiz_generate($data_quiz_src) {
        // generate question correct response and so on ... 
        // extract all possible answer
        $all_possible_answer = array();
        foreach ($data_quiz_src as $single_quiz) {
            $all_correct_answer = explode('|', $single_quiz['correct_answer']);
            $all_possible_answer[] = $all_correct_answer[0];
        }


        $out = array();
        $index = 0;
        foreach ($data_quiz_src as $single_quiz) {
            shuffle($all_possible_answer);

            $single_quiz['all_correct_answer'] = explode('|', $single_quiz['correct_answer']);

            $single_quiz['possible_answer'] = array($single_quiz['all_correct_answer'][0]);

            //  add wrong answer to $possible_answer from input data
            if (isset($single_quiz["wrong_answer"])) {
                $possible_wrong_answer = explode('|', $single_quiz["wrong_answer"]);
                $single_quiz['possible_answer'] = array_merge($single_quiz['possible_answer'], $possible_wrong_answer);
            }
            //  add random wrong answer to $possible_answer
            $single_quiz['possible_answer'] = array_merge($single_quiz['possible_answer'], $all_possible_answer);

            // eliminate duplicates
            $single_quiz['possible_answer'] = array_unique($single_quiz['possible_answer']);

            //remove eventually emtpy element
            $single_quiz['possible_answer'] = array_filter($single_quiz['possible_answer']);

            //get only the correct number of elements:
            $single_quiz['possible_answer'] = array_slice($single_quiz['possible_answer'], 0, $this->configuration['num_options']['value']);

            // shuffle all data:
            shuffle($single_quiz['possible_answer']);

            $single_quiz['all_question'] = explode('|', $single_quiz['question']);
            shuffle($single_quiz['all_question']);
            $single_quiz['question'] = $single_quiz['all_question'][0];


            $single_quiz['response_type'] = !empty($single_quiz['response_type']) ? $single_quiz['response_type'] : $this->configuration['default_response_type']['value'];


            // add id of the correct_answer to correct answer if the answer_type is 'options' 
            if ($single_quiz['response_type'] == "options") {
                $key = array_search($single_quiz['all_correct_answer'][0], $single_quiz['possible_answer']);
                $single_quiz['all_correct_answer'][] = $key;
            }


            $output_keys = array('id', 'question', 'all_correct_answer', 'possible_answer', 'response_type');


            $out[$index] = array();
            foreach ($output_keys as $single_key) {

                $out[$index][$single_key] = isset($single_quiz[$single_key]) ? $single_quiz[$single_key] : "";
            }


            $index ++;
        }
        return $out;
    }

    private function quiz_switch_question_with_answer($data_quiz_src) {
        $out = array();
        $index = 0;
        foreach ($data_quiz_src as $single_quiz) {
            $out[$index] = $single_quiz;
            $out[$index]['question'] = $single_quiz['correct_answer'];
            $out[$index]['correct_answer'] = $single_quiz['question'];
            $index ++;
        }
        return $out;
    }

    private function quiz_filter($data_quiz_src, $tags, $min_difficult_level, $max_difficult_level) {
        $out = array();
        $a_tags = explode('|', $tags);

        foreach ($data_quiz_src as $single_quiz) {


            $difficult_level = !empty($single_quiz['difficult_level']) ? $single_quiz['difficult_level'] : 1;
     
            if (!empty($single_quiz['question']) && !empty($single_quiz['correct_answer'])) {

                if (($difficult_level >= $min_difficult_level) && ($difficult_level <= $max_difficult_level)) {

                    if (empty($tags)) {
                        $out[] = $single_quiz;
                    } else {
                        // tags are selected
                        $tag_found = false;
                        foreach ($a_tags as $single_tag) {

                            if (stripos($single_quiz['tags'], $single_tag) !== false) {
                                $tag_found = true;
                            }
                        }
                        if ($tag_found) {

                            $out[] = $single_quiz;
                        }
                    }
                }
            }
        }
        return $out;
    }

}
