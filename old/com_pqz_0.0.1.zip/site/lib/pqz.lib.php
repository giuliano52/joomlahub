<?php

function print_pre($obj) {
    /*
     * Print all the content of a variable with pre 
     */
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
}



function get_quiz_list() {
    // get the list of avilable quiz from db and filesystem
    $db = JFactory::getDbo();
    $query = $db->getQuery(true);
    $query->select($db->quoteName(array('id_quiz', 'title', 'description')));
    $query->from($db->quoteName('#__pqz_quiz_name'));
    $db->setQuery($query);
    //check if error
    if ($db->getErrorNum()) {
        echo $db->getErrorMsg();
        exit;
    }
    $results = $db->loadObjectList();
    return $results;
}


function get_quiz_field($id_quiz,$field) {
    // get the list of avilable quiz from db and filesystem
    $id_quiz = (int)$id_quiz;
    $db = JFactory::getDbo();
    $query = $db->getQuery(true);
    $query->select($db->quoteName($field));
    $query->from($db->quoteName('#__pqz_quiz_name'));
    $query->where($db->quoteName('id_quiz') . ' = '. $db->quote($id_quiz));
    $db->setQuery($query);
    //check if error
    if ($db->getErrorNum()) {
        echo $db->getErrorMsg();
        exit;
    }
    $results = $db->loadResult();
    return $results;
}
