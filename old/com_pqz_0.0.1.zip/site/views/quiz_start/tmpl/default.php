<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<br>
<br>
<a href="<?php echo JRoute::_('index.php?option=com_pqz&task=ask_question&id_question=0'); ?>">


    

    <b><?= JText::_('COM_PQZ_START_QUIZ') ?></b>
</a>

