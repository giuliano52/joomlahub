<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.modal', 'a.modal');
?>
<h1>Scegli il tuo quiz</h1>
<table class="table table-striped">
    <thead>
        <tr>

            <th width="1%" class="nowrap center">
                &nbsp;
            </th>
            <th class="left">
                <?php echo JHtml::_('searchtools.sort', 'COM_PQZ_QUIZ_NAME', 'a.name'); ?>
            </th>
            <th class="left">
                <?php echo JHtml::_('searchtools.sort', 'COM_PQZ_QUIZ_DESCRIPTION', 'a.name'); ?>
            </th>

        </tr>

    </thead>
    <tbody>

        <?php
        $i = 0;
        foreach ($this->items as &$row) {
            ?>
    
            <tr class="row<?= $i % 2; ?>">
                <td><?= $i+1 ?></td>
                <td>
                    <a href="<?php echo JRoute::_('index.php?option=com_pqz&task=edit_single_csv&id_quiz=' . (int) $row->id_quiz); ?>">
                        <?= $row->title ?></a></td>
                <td><?= $row->description ?></td>

            </tr>
            <?php
            $i++;
        }
        ?>
    </tbody>
</table>
<?php

//Messaggio personalizzato: <?php echo $this->msg; 

?>
