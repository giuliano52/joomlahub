<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

class pqzViewedit_csv extends JViewLegacy {

    protected $params;

// Overwriting JView display method
    function display($tpl = null) {

        $app = JFactory::getApplication();
        $this->params = $app->getParams('');
        $this->_prepareDocument();


        $this->items = $this->get('Items');

        parent::display($tpl);
    }

    protected function _prepareDocument() {
        $app = JFactory::getApplication();
        $menus = $app->getMenu();
        //     $title = null;
    }

}
