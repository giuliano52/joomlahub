<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
JHtml::stylesheet(Juri::base() . 'components/com_pqz/media/css/com_pqz.css');


?>


<?php
if ($_SESSION['pqz_quiz_conf']['num_question'] == $_SESSION['pqz_quiz_conf']['num_correct_answer']) {
    // all answer are correct
    ?>

    <?= JText::_('COM_PQZ_CONGRATULATION') ?>
    <img src="<?= $_SESSION['pqz_quiz_conf']['congratulation_image'] ?>" alt="Congratulation">
    <?php
} else {
    // Some wrong answer
    ?>
    <div class="com_pqz_question_header">
        Hai risposto giusto a su domande
    </div>
    <div class="com_pqz_question_body">
        <?php
        foreach ($_SESSION['pqz_quiz_question'] as $key => $question) {

            if ($question['response_type'] == 'options') {
                $answered_question = $question['possible_answer'][$question['answered_question']];
                $correct_answer = $question['all_correct_answer'][0];
            } else {
                $answered_question = $question['answered_question'];
                $correct_answer = $question['all_correct_answer'][0];
            }
            if ($question['answer_is_correct']) {
                $class = "com_pqz_question_response_correct";
                $text = JText::_('COM_PQZ_CORRECT_ANSWER') . " " . $answered_question;
            } else {
                $class = "com_pqz_question_response_wrong";
                $text = JText::_('COM_PQZ_WRONG_ANSWER') . " " . $answered_question . "<br>" . JText::_('COM_PQZ_CORRECT_ANSWER_WAS') . " " . $correct_answer;
            }
            ?>


            <div class="com_pqz_question">
                <div class="<?= $class ?>" >
                    <?= $question['question']; ?>
                </div>

            </div>
            <div class="com_pqz_possible_answer">
                <div class="<?= $class ?>" >
                    <?= $text; ?>
                </div>


            </div>


            <?php
        }
        ?>
    </div>
    <div class="com_pqz_question_footer">
        <a href="<?= JRoute::_("index.php?option=com_pqz&task=quiz_start&id_quiz=".$_SESSION['pqz_quiz_conf']['id_quiz']); ?>">
            <?= JTEXT::_('COM_PQZ_TRY_AGAIN'); ?>
        </a>
    </div>
    <?php
}
?>