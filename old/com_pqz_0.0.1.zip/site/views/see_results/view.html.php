<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

class pqzViewsee_results extends JViewLegacy {

    // Overwriting JView display method
    function display($tpl = null) {
        $msg = $this->_models['pqz']->get('msg');
  
        parent::display($tpl);
    }

}
