<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
JHtml::stylesheet(Juri::base() . 'components/com_pqz/media/css/com_pqz.css');
?>
<table>
    <?php
    $data = $this->quiz_src;
    $quiz_id = $data['id_quiz'];
    
    foreach ($data[$quiz_id] as $key => $value) {
        ?>
    <tr>
        <td>
            <?=$key?>
        </td>
        
        <td>
            <?=$value?>
        </td>
        
    </tr>
        
      <?php  
    }
    ?>
</table>
FINE
