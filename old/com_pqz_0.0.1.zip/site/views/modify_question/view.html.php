<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

class pqzViewmodify_question extends JViewLegacy {

    protected $quiz_src;

    // Overwriting JView display method
    function display($tpl = null) {

        $this->quiz_src = $_SESSION['pqz_quiz_src'];
        parent::display($tpl);
    }

}
