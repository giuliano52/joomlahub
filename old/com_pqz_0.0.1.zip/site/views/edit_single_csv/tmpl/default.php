<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$jinput = JFactory::getApplication()->input;
$id_quiz = $jinput->get('id_quiz', '', 'int');

?>
<br>
<table class="com_pqz_edit_csv">
    <tr>
        <th>Edit</th>
        <th><?= JText::_('COM_PQZ_QUESTION') ?></th>
    </tr>
    <?php
    $index = 0;
    foreach ($this->items as $item) {
        ?>
        <tr>
            <td class="com_pqz_edit_csv">
                <a href="<?php echo JRoute::_("index.php?option=com_pqz&task=modify_question&id_question=$index&id_quiz=$id_quiz"); ?>">
                    <?= JText::_('COM_PQZ_EDIT') ?>
                </a>
            </td>
            <td class="com_pqz_edit_csv">
                <?= htmlspecialchars($item['question']) ?>
            </td>
        </tr>

        <?php
        $index ++;
    }
    ?>

                <tr>
            <td class="com_pqz_edit_csv">
                <a href="<?php echo JRoute::_("index.php?option=com_pqz&task=modify_question&id_question=new&id_quiz=$id_quiz"); ?>">
                    <?= JText::_('COM_PQZ_NEW') ?>
                </a>
            </td>
            <td class="com_pqz_edit_csv">
                &nbsp;
            </td>

        
</table>
