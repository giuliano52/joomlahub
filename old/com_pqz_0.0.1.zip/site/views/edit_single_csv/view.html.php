<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
JHtml::stylesheet(Juri::base() . 'components/com_pqz/media/css/com_pqz.css');

// import Joomla view library
jimport('joomla.application.component.view');

class pqzViewedit_single_csv extends JViewLegacy {

    // Overwriting JView display method
    function display($tpl = null) {

        $this->items = $this->get('Items');
        parent::display($tpl);
    }

}
