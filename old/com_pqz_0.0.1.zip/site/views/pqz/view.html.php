<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * HTML View class for the HelloWorld Component
 */
class PqzViewPqz extends JViewLegacy {

    // Overwriting JView display method
    function display($tpl = null) {

//     $this->msg = $results[0];
        // Display the view
        $results = $this->get('Msg');
 
        $this->items = $results;
        parent::display($tpl);
    }
/*
    function QuizInitialize($tpl = null) {
        print "model quiz_start";
    }
 * 
 */

}
