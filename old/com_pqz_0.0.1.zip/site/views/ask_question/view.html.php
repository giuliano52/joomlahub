<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

class pqzViewask_question extends JViewLegacy {

    // Overwriting JView display method
    function display($tpl = null) {


        $msg = $this->_models['pqz']->get('msg');



        $this->items = $msg;

        // Display the view
//        $this->items = $results;
        parent::display($tpl);
    }

}
