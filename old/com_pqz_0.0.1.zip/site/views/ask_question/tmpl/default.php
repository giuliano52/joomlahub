<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
JHtml::stylesheet(Juri::base() . 'components/com_pqz/media/css/com_pqz.css');

$msg = $this->items;
$question = $msg['question'];
$id_question = $msg['id_question'];
$all_answerd = $msg['all_answered'];
$base_img_path = Juri::base() . 'components/com_pqz/media/img';
?>

<div class="com_pqz_question_header">

    <?php
    // TODO don't use the session use a call to the model ... '
    foreach ($_SESSION['pqz_quiz_question'] as $key => $single_question) {
        if (isset($single_question['answered_question'])) {
            $img_name = "$base_img_path/Circle-question-green.png";
        } else {
            $img_name = "$base_img_path/Circle-question-yellow.png";
        }

        if ($key == $id_question) {
            $class = 'com_pqz_circle-selected';
        } else {
            $class = 'com_pqz_circle';
        }
        ?>
        <span class="<?= $class ?>" > 
            <a href="<?php echo JRoute::_("index.php?option=com_pqz&task=ask_question&id_question=$key"); ?> " >
                <img src="<?= $img_name ?>" > 

                <?= $key + 1; ?>
            </a>
        </span>
        <?php
    }
    ?>

    <br>
<?= JText::_('COM_PQZ_QUESTION'); ?>

</div>

<div class="com_pqz_question_body">

    <div class="com_pqz_question">

<?php
echo $question['question'];
?>

    </div>

    <div class="com_pqz_possible_answer">

        <form action="<?php echo JRoute::_('index.php?option=com_pqz&task=ask_question'); ?>" method="post" name="question" >
            <input type="hidden" name="id_question" value="<?= $id_question ?>">

<?php
if ($question['response_type'] == 'options') {
    foreach ($question['possible_answer'] as $key => $single_answer) {
        ?>
                    <input type="radio" name="q_0" value="<?= $key ?>" >
                    <?= $single_answer ?>
                    <br>
                    <?php
                }
            } else {
                ?>
                <input type="text" name="q_0" value="<?= $question['answered_question'] ?>" >
                <?php
            }
            ?>
                <br> <br>
            <input type="submit" name="submit_question" value="OK">
        </form>

    </div>
</div>
<div class="com_pqz_question_footer">
<?php if ($all_answerd) { ?>


        <a href="<?php echo JRoute::_("index.php?option=com_pqz&task=see_results"); ?> " >
    <?= JText::_('COM_PQZ_SEE_RESULTS'); ?>

        </a>
    <?php
}
?>
</div>