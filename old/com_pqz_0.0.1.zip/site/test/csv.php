<html>
    <head>
        <meta charset="utf-8">
    </head>

    <?php
    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */

    require_once( '../lib/csv_gd.class.php');
    require_once( '../lib/pqz.lib.php');


    $csv = new csv_gd('../media/data/src/test/test.csv');

    $csv_array = $csv->csv_to_array();
    $filename = "../media/data/src/test/test1.csv";

    $csv_array[5]['correct_answer']=rand();
    $csv->set_filename($filename);
    $csv->array_to_csv($csv_array);
 
    print_pre($csv_array);
    ?>

</html>

