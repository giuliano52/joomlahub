<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');

/**
 * Methods supporting a list of Quiz records.
 */
class pqzModeledit_csv extends JModelList {

    public function getItems() {

        $results = get_quiz_list();

        return $results;
    }

}
