<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla modelitem library
jimport('joomla.application.component.modelitem');

class PqzModelPqz extends JModelItem {

    protected $msg;

    public function getMsg() {

        $results = get_quiz_list();
        return $results;
    }

    public function QuizInitialize($id_quiz) {

        $fields_selected = array(
            'num_options',
            'max_question_total',
            'min_diffucult_level',
            'max_diffucult_level',
            'default_response_type',
            'randomize_question',
            'reverse_question',
            'tags',
            'question_filename',
            'congratulation_file',
        );

        $db = JFactory::getDbo();


        $query = $db->getQuery(true);
        $query->select($db->quoteName($fields_selected));
        $query->from($db->quoteName('#__pqz_quiz_name'));
        $query->where($db->quoteName('id_quiz') . ' LIKE ' . $db->quote($id_quiz));

        $db->setQuery($query);

        //check if error
        if ($db->getErrorNum()) {
            echo $db->getErrorMsg();
            exit;
        }

        $results = $db->loadAssoc();


        if (!empty($results['question_filename'])) {
            $pqz_quiz = new pqz();

            foreach ($fields_selected as $single_field) {
                $pqz_quiz->configuration[$single_field]['value'] = $results[$single_field];
            }
            $pqz_quiz->configuration['question_filename']['value'] = JPATH_ROOT . '/' . $results['question_filename'];
            $pqz_quiz->generate_question();

            $csv_congratulation = new csv_gd(JPATH_ROOT . '/' . $results['congratulation_file']);

            $_SESSION['pqz_quiz_question'] = $pqz_quiz->quiz_questions;
            $_SESSION['pqz_quiz_conf']['question_filename'] = $pqz_quiz->configuration['question_filename']['value'];
            $_SESSION['pqz_quiz_conf']['num_question'] = count($pqz_quiz->quiz_questions);

            $_SESSION['pqz_quiz_conf']['congratulation_image'] = $csv_congratulation->pick_one_field_random('url');
            $_SESSION['pqz_quiz_conf']['id_quiz'] = $id_quiz;
        } else {

            die("question_filename assente");
        }
    }

    public function getQuestion($id_question) {

// estrai una domanda dalla sessione 
        if (isset($_SESSION['pqz_quiz_question'][$id_question])) {
            $question = $_SESSION['pqz_quiz_question'][$id_question];
        } else {
            die('ERROR: getQuestion Session empty');
        }

        $msg = array(
            'question' => $question,
            'id_question' => $id_question,
            'all_answered' => $this->checkAnsweredQuestion()
        );

        $this->msg = $msg;

        return $question;
    }

    public function storeAnswer($id_question, $answer) {
        $_SESSION['pqz_quiz_question'][$id_question]["answered_question"] = $answer;
        return true;
    }

    private function checkAnsweredQuestion() {
        $all_answer = true;
        foreach ($_SESSION['pqz_quiz_question'] as $question) {
            if (!isset($question['answered_question'])) {
                $all_answer = false;
            }
        }
        return $all_answer;
    }

    public function final_verify_correct_answer() {
        $num_correct_answer = 0;
        foreach ($_SESSION['pqz_quiz_question'] as $key => $data_single_quiz) {
            $all_right_question = array();
            foreach ($data_single_quiz['all_correct_answer'] as $single_correct_answer) {
                $all_right_question[] = trim(strtoupper($single_correct_answer));
            }
            $answered_question = trim(strtoupper($data_single_quiz["answered_question"]));
            if (in_array($answered_question, $all_right_question)) {
                $_SESSION['pqz_quiz_question'][$key]['answer_is_correct'] = TRUE;
                $num_correct_answer++;
            } else {
                $_SESSION['pqz_quiz_question'][$key]['answer_is_correct'] = FALSE;
            }
        }
        $_SESSION['pqz_quiz_conf']['num_correct_answer'] = $num_correct_answer;
    }

    public function getData($id_quiz, $id_question) {
// get dat from csv to be modified

        $filename = get_quiz_field($id_quiz, 'question_filename');

        $csv_file = new csv_gd($filename);
        $quiz_src = $csv_file->csv_to_array();
        $this->items = $quiz_src;
        $_SESSION['pqz_quiz_src']['data'] = $quiz_src;
        $_SESSION['pqz_quiz_src']['id_quiz'] = $id_quiz;
        $_SESSION['pqz_quiz_src']['id_question'] = $id_question;
        
        return $quiz_src;
    }

}
