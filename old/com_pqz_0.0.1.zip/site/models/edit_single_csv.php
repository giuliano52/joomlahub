<?php

defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');

/**
 * Methods supporting a list of Quiz records.
 */
class pqzModeledit_single_csv extends JModelList {

    public function getItems() {
        $filename = $_SESSION['pqz_quiz_conf']['question_filename'];
     
        $csv_file = new csv_gd($filename);
        $data_quiz_src = $csv_file->csv_to_array();

        return $data_quiz_src;
    }

}
